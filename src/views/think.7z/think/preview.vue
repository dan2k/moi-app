<template>
	<div class="form-group">
		<ckeditor
			style="background-color: white; height: 100%"
			:editor="editor"
			v-model="data"
			:config="editorConfig"
			:disabled="true"
			:isReadonly="true"
		></ckeditor>
	</div>
</template>

<script>
import { ref, reactive, onMounted } from "vue";
import CKEditor from "@ckeditor/ckeditor5-vue";
import DocumentEditor from "@ckeditor/ckeditor5-build-decoupled-document";
// import ClassEditor from "@ckeditor/ckeditor5-build-classic";
export default {
	inheritAttrs: false,
	components: {
		ckeditor: CKEditor.component,
	},
	props: {
		disabled: {
			type: Boolean,
			default: true,
		},
		data: {
			type: String,
			default: null,
		},
	},
	setup(props) {
		const editorData = ref(props.data);
		const editor = ref(DocumentEditor);
		const editorConfig = reactive({});
		const onReady = (editor) => {
			editor.ui
				.getEditableElement()
				.parentElement.insertBefore(
					editor.ui.view.toolbar.element,
					editor.ui.getEditableElement()
				);
			editor.isReadOnly = props.disabled;
			editor.ui.view.toolbar.element.style.display = props.disabled
				? "none"
				: "";
		};
		onMounted(() => {});

		return {
			editor,
			editorData,
			onReady,
			editorConfig,
		};
	},
};
</script>

<style scored>
p {
	color: black;
}
.form-group p {
	margin-top: 0px;
	margin-bottom: 0px;
	line-height: 18px;
}
</style>
