<template>
	<div class="container mx-auto col-11">
		<div class="post-content px-5 py-5 text-white rounded">
			<div class="float-right" style="position: relation">
				<span
					@click="
						$router.push({
							path: '/think',
							query: {
								pid: $route.query.pid,
							},
						})
					"
				>
					<i
						class="far fa-hand-point-left text-info"
						style="cursor: pointer"
					></i>
				</span>
				&nbsp;
				<span v-if="post.status == 0" @click="upStatus(1)"
					><i
						class="fas fa-battery-empty text-danger"
						style="cursor: pointer"
						title="หัวข้อใหม่"
					></i
				></span>
				<span v-if="post.status == 1" @click="upStatus(2)"
					><i
						class="fas fa-battery-half text-warning"
						style="cursor: pointer"
						title="นำเสนอราชการ"
					></i
				></span>
				<span v-if="post.status == 2" @click="upStatus(2)">
					<i
						class="fas fa-battery-full text-success"
						style="cursor: pointer"
						title="ดำเนินการเรียบร้อยแล้ว"
					></i>
				</span>

				&nbsp;
				<span v-if="post.think_add_emp_id == empid" @click="edit">
					<i
						class="fas fa-edit text-info"
						style="cursor: pointer"
					></i>
				</span>

				&nbsp;
				<div
					v-if="isNote"
					style="
						position: fixed;
						top: 15%;
						right: 0%;
						z-index: 9999;
					"
				>
					<div class="postit text-center">
						<i class="fas fa-comment-dots text-primary"></i
						>&nbsp;<b class="px-2 text-secondary">บันทึกสรุป</b>&nbsp;<i
							class="fas fa-comment-dots text-primary"
						></i>
						<h5 class="float-right pr-1">
							<span @click="isNote = false">
								<i
									class="far fa-eye-slash text-info mt-0 pt-0"
									style="cursor: pointer"
								></i>
							</span>
						</h5>
						<hr />
						<div class="px-2 text-left">
							<textarea
								class="border-0"
								style="
									width: 100%;
									height: 100%;
									line-height: 14px;
									background-color: #ffff88;
								"
								:rows="12"
								:disabled="true"
								v-model="post.think_note"
							></textarea>
						</div>
					</div>
				</div>
				<div
					style="
						position: fixed;
						top: 18%;
						right: 20px;
						z-index: 9998;
					"
				>
					<span @click="isNote = true">
						<i
							class="far fa-eye fa-2x text-warning"
							style="cursor: pointer"
						></i>
					</span>
				</div>
			</div>

			<div>
				<b
					><i class="fas fa-lightbulb"></i>
					&nbsp;<u>หัวข้อ:</u>&nbsp;&nbsp;</b
				>
				<p
					class="text-white"
					style="font-size: 14px; text-indent: 2em"
				>
					&nbsp;&nbsp;{{ post.think_title }}
				</p>
			</div>

			<div class="mb-2">
				<b
					><i class="fas fa-list-alt"></i> &nbsp;<u
						>รายละเอียด:</u
					></b
				>
			</div>

			<preview
				:data="post.think_detail"
				style="border-width: 0xp"
			></preview>
			<div class="col-12">
				<hr />
				<div class="float-right text-white">
					<i class="far fa-id-card text-info"></i>
					{{ post.think_add_emp_id }} &nbsp;
					<i class="fas fa-user-tie text-info"></i>&nbsp;{{
						post.think_thiname
					}}
					&nbsp;<i class="far fa-clock"></i> &nbsp;{{
						post.think_date
					}}
				</div>
			</div>
		</div>

		<br />
		<b>ความคิดเห็น</b>
		<div
			class="col-12 px-0 border border-default border-bottom-0 w-25"
		></div>
		<div class="container">
			<div
				class="card my-2 rounded"
				v-for="(c, i) of comments"
				:key="i"
			>
				<div
					class="card-body"
					:class="{ pin: c.comment_pin_flag == 1 }"
				>
					<div class="row py-1">
						<div class="col-1 mx-auto">
							<img
								:src="`${server}/imgs/member/${c.comment_emp_id}.jpg`"
								class="border-primary rounded-circle"
								style="width: 50px; height: 50px"
							/>
							<!-- <div
									class="badge bg-secondary"
									style="font-size: 12px"
								>
									{{ c.sect_id }}
								</div> -->
						</div>
						<div class="col-11">
							<div
								class="float-right my-0 mx-0 px-0 py-0"
								style="font-size: 10px"
							>
								<span
									@click="
										upComment(
											'pin',
											c.comment_id,
											c.comment_detail
										)
									"
								>
									<i
										class="fas fa-thumbtack text-warning"
										style="cursor: pointer"
									></i>
								</span>

								&nbsp;
								<!-- <span >
									<i
										v-if="
											(c.comment_emp_id = empid)
										"
										class="fas fa-edit text-info"
										style="cursor: pointer"
									></i
									>&nbsp;
								</span> -->
								<span
									@click="
										upComment(
											'del',
											c.comment_id,
											c.comment_detail
										)
									"
								>
									<i
										v-if="
											c.comment_emp_id == empid
										"
										class="fas fa-trash-alt text-danger"
										style="cursor: pointer"
									></i>
								</span>
							</div>
							<hr />
							<preview :data="c.comment_detail"></preview>
						</div>
					</div>
					<div
						class="float-right mx-0 px-0 my-0 py-0"
						style="font-size: 10px"
						:class="{ 'text-white': c.comment_pin_flag == 1 }"
					>
						<div
							class="col-12 px-0 border border-default border-bottom-0 w-100"
						></div>
						<i class="far fa-id-card text-info"></i>&nbsp;{{
							c.comment_emp_id
						}}&nbsp;<i class="fas fa-user-tie text-info"></i
						>&nbsp;{{ c.thiname }} &nbsp;<i
							class="far fa-clock"
						></i>
						&nbsp;{{ c.comment_date }}
					</div>
				</div>
			</div>
		</div>
		<div class="jumbotron mt-5 py-2 col-8 mx-auto">
			<form
				ref="form"
				@submit.prevent="submit"
				class="needs-validation"
				novalidate
			>
				<div class="form-row justify-content-center">
					<div class="col-12">
						<editor
							:disabled="false"
							label="แสดงความคิดเห็น"
							:v="v.comment_detail"
							@delete-img="delImg"
							:isCancel="true"
							:url="uploadUrl"
						></editor>
					</div>
				</div>
				<div class="col-12"></div>
				<div class="col-12 text-center">
					<button class="btn btn-primary btn-sm mr-2">
						<i class="fas fa-save"></i> บันทึก
					</button>
					<button
						class="btn btn-danger btn-sm mr-2"
						type="reset"
						@click="cancel"
					>
						<i class="fas fa-redo-alt"></i> ยกเลิก
					</button>
				</div>
			</form>
		</div>
	</div>
	<loading v-if="isLoading"></loading>
</template>

<script>
import { ref, reactive, computed, onMounted, nextTick } from "vue";
import { useRouter, useRoute } from "vue-router";
import { useStore } from "vuex";
import { api } from "@/helper/api";
import Editor from "./editor.vue";
import Preview from "./preview.vue";
import Swal from "sweetalert2";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
// import Loading from "@/views/loading.vue";
// import NProgress from 'nprogress';
export default {
	components: {
		Editor,
		Preview,
		// Loading,
	},
	setup() {
		let post = reactive({
			think_title: null,
			think_detail: null,
			think_thiname: null,
			think_add_emp_id: null,
			think_date: null,
			status: null,
			think_note: null,
		});
		let comment_detail = ref("");
		let comments = ref([]);
		let isSubmit = false;
		let isNote = ref(true);
		const router = useRouter();
		const server = import.meta.env.VITE_PRIVATE_API_URL;
		// console.log('server='+server);
		const route = useRoute();
		const store = useStore();
		const authData = store.getters["auth/getAuthData"];
		const empid = authData.user[0].emp_id;
		const isLoading = ref(false);
		const rules = computed(() => ({
			comment_detail: {
				required: helpers.withMessage("ห้ามเป็นค่าว่าง", required),
			},
		}));
		const v = useVuelidate(rules, { comment_detail });

		const id = route.params.id;
		const uploadUrl = `${
			import.meta.env.VITE_PRIVATE_API_URL
		}/upload.php?id=${empid}`;

		async function getComment() {
			isLoading.value = true;
			try {
				const response = await api.get(
					`/thinktank/v1/comment/${id}`
				);
				if (response && response.data) {
					if (response.data.status) {
						comments.value = response.data.data;
						isLoading.value = false;
						return;
					} else {
						comments.value = [];
						isLoading.value = false;
						console.log(response.data.error);
						return;
					}
				}
				throw response.data.error;
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
				isLoading.value = false;
			}
		}
		const getPost = async () => {
			isLoading.value = true;
			try {
				const response = await api.get(`/thinktank/v1/post/${id}`);
				if (response && response.data) {
					if (response.data.status) {
						let tmp = response.data.data;
						post.think_detail = tmp.think_detail;
						post.think_title = tmp.think_title;
						post.think_thiname = tmp.think_thiname;
						post.think_add_emp_id = tmp.think_add_emp_id;
						post.think_date = tmp.think_date;
						post.think_note = tmp.think_note;
						post.status = tmp.think_status;
						// post=tmp;
						//console.log(post);
						isLoading.value = false;
						return;
					}
					throw response.data.error;
				}
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
				isLoading.value = false;
			}
		};
		const setRead = async () => {
			try {
				let response = await api.post(`/thinktank/v1/setRead`, {
					id: id,
				});
				if (response && response.data) {
					if (response.data.status) {
						return;
					}
				}
				throw response.data.error;
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
			}
		};
		onMounted(async () => {
			// NProgress.start();
			await getPost();
			await setRead();
			await getComment();
			// NProgress.done();
		});
		function delImg(obj, n) {
			if (isSubmit) {
				isSubmit = false;
				return;
			}
			let files = [];
			obj.imagesSrc.forEach((it, i) => {
				let tmp = it.split("/");
				files.push(tmp[tmp.length - 1]);
			});
			let data = {
				id: "empid",
				filenames: files,
				action: "comment",
			};
			fetch(`${import.meta.env.VITE_PRIVATE_API_URL}/delete.php`, {
				method: "POST",
				body: JSON.stringify(data),
				headers: {
					"Content-type": "application/json; charset=UTF-8",
				},
			});
		}
		async function submit() {
			this.v.$touch();
			if (this.v.$error) return;

			try {
				const response = await api.post("/thinktank/v1/comment", {
					emp_id: empid,
					comment_detail: comment_detail.value,
					think_id: id,
				});
				if (response && response.data) {
					if (response.data.status) {
						isSubmit = true;
						this.cancel();
						await getComment();
						return;
					}
				}
				throw response.data.error;
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
			}
		}
		function cancel() {
			self = this;
			self.v["comment_detail"].$model = "";
			nextTick(() => {
				self.v.$reset();
			});
		}
		const upStatus = async (s) => {
			let ck0 = post.status == 0 ? " checked " : "";
			let ck1 = post.status == 1 ? " checked " : "";
			let ck2 = post.status == 2 ? " checked " : "";
			const rs = await Swal.fire({
				title: "ปรับปรุงสถานะการดำเนินการ",
				html: `
				<div class="container text-left">
					<div class="form-check text-danger">
						<input class="form-check-input" type="radio" name="postStatus" id="postStatus0" value="0" ${ck0}>
						<label class="form-check-label" for="postStatus0">
						หัวข้อใหม่
						</label>
						<i class="fas fa-battery-empty text-danger float-right" ></i>
					</div>
					<div class="form-check text-warning">
						<input class="form-check-input" type="radio" name="postStatus" id="postStatus1" value="1" ${ck1}>
						<label class="form-check-label" for="postStatus1">
						นำเสนอราชการ
						</label>
						<i class="fas fa-battery-half text-warning float-right" ></i>
					</div>
					<div class="form-check text-success">
						<input class="form-check-input" type="radio" name="postStatus" id="postStatus2" value="2" ${ck2}>
						<label class="form-check-label" for="postStatus2">
						ดำเนินการเรียบร้อยแล้ว 
						</label>
						<i class="fas fa-battery-full text-success float-right" ></i>
					</div>
					<div class="form-group"><label for="txtNote"><u>บันทึกสรุป</u></label><textarea name="txtNote" rows=8 id="txtNote" class="form-control">${post.think_note}</textarea></div>
				</div>
				`,
				focusConfirm: false,
				preConfirm: () => {
					let postStatus = document.querySelector(
						'input[name="postStatus"]:checked'
					)
						? document.querySelector(
								'input[name="postStatus"]:checked'
						  ).value
						: 0;
					let txtNote =
						document.querySelector('textarea[name="txtNote"]')
							.value == "null"
							? ""
							: document.querySelector(
									'textarea[name="txtNote"]'
							  ).value;
					return { postStatus, txtNote };
				},
			});
			if (rs.isConfirmed) {
				isLoading.value = true;
				try {
					let response = await api.post(
						`/thinktank/v1/post/upStatus`,
						{
							empid: empid,
							status: rs.value.postStatus,
							id: id,
							note: rs.value.txtNote,
						}
					);
					if (response && response.data) {
						if (response.data.status) {
							await getPost();
							isLoading.value = false;
							return;
						}
					}
					throw response.data.error;
				} catch (err) {
					Swal.fire({
						icon: "error",
						title:
							'<span style="color:red">แจ้งข้อผิดพลาด</span>',
						text: err,
					});
					isLoading.value = false;
				}
			}
		};
		const upComment = async (type, commentid, detail) => {
			isLoading.value = true;
			let response = null;
			try {
				if (type == "del") {
					/* let domParser = new DOMParser();
					let htmlString = detail;
					let docElement = domParser.parseFromString(
						htmlString,
						"text/html"
					).documentElement;
					var emCollection = docElement.getElementsByTagName(
						"figure"
					);
					let afile = [];
					for (let i = 0; i < emCollection.length; i++) {
						let tmp = emCollection[0].childNodes[0].src;
						let filename = /([^\\]+)$/.exec(tmp)[1];
						let x = filename.split("/");
						afile.push(x[x.length - 1]);
					} */
					response = await api.post(
						`/thinktank/v1/comment/delete`,
						{
							empid: empid,
							id: id,
							commentid: commentid,
							// afile: afile,
						}
					);
				} else {
					response = await api.post(
						`/thinktank/v1/comment/pin`,
						{
							empid,
							id,
							commentid,
						}
					);
				}
				if (response && response.data) {
					if (response.data.status) {
						isSubmit = true;
						await getComment();
						isLoading.value = false;
						return;
					}
				}
				throw response.data.error;
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
				isLoading.value = false;
			}
		};
		const edit = () => {
			// console.log("edit");
			router.push({
				name: "think-edit",
				params: { id: id },
				replace: true,
			});
		};
		return {
			post,
			comments,
			v,
			submit,
			cancel,
			delImg,
			comment_detail,
			empid,
			upStatus,
			isNote,
			upComment,
			server,
			uploadUrl,
			edit,
			isLoading,
		};
	},
};
</script>
<style scoped>
.post-content {
	background: rgb(63, 63, 140);
	background: linear-gradient(
		90deg,
		rgba(63, 63, 140, 1) 0%,
		rgba(193, 190, 190, 1) 100%
	);
}
.pin {
	background: rgb(193, 190, 190);
	background: linear-gradient(
		90deg,
		rgba(193, 190, 190, 1) 0%,
		rgba(63, 63, 140, 1) 100%
	);
}
.postit {
	line-height: 1;
	text-align: center;
	width: 275px;
	margin: 20px;
	min-height: 250px;
	max-height: 250px;
	padding-top: 2px;
	position: relative;
	border: 1px solid #e8e8e8;
	border-top: 7px solid #fdfd86;
	font-family: "Reenie Beanie";
	font-size: 12px;
	border-bottom-right-radius: 60px 5px;
	display: inline-block;
	background: #ffff88; /* Old browsers */
	background: -moz-linear-gradient(
		-45deg,
		#ffff88 81%,
		#ffff88 82%,
		#ffff88 82%,
		#ffffc6 100%
	); /* FF3.6+ */
	background: -webkit-gradient(
		linear,
		left top,
		right bottom,
		color-stop(81%, #ffff88),
		color-stop(82%, #ffff88),
		color-stop(82%, #ffff88),
		color-stop(100%, #ffffc6)
	); /* Chrome,Safari4+ */
	background: -webkit-linear-gradient(
		-45deg,
		#ffff88 81%,
		#ffff88 82%,
		#ffff88 82%,
		#ffffc6 100%
	); /* Chrome10+,Safari5.1+ */
	background: -o-linear-gradient(
		-45deg,
		#ffff88 81%,
		#ffff88 82%,
		#ffff88 82%,
		#ffffc6 100%
	); /* Opera 11.10+ */
	background: -ms-linear-gradient(
		-45deg,
		#ffff88 81%,
		#ffff88 82%,
		#ffff88 82%,
		#ffffc6 100%
	); /* IE10+ */
	background: linear-gradient(
		135deg,
		#ffff88 81%,
		#ffff88 82%,
		#ffff88 82%,
		#ffffc6 100%
	); /* W3C */
	filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#ffff88', endColorstr='#ffffc6',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */
}

.postit:after {
	content: "";
	position: absolute;
	z-index: -1;
	right: -0px;
	bottom: 20px;
	width: 200px;
	height: 25px;
	background: rgba(0, 0, 0, 0.2);
	box-shadow: 2px 15px 5px rgba(0, 0, 0, 0.4);
	-moz-transform: matrix(-1, -0.1, 0, 1, 0, 0);
	-webkit-transform: matrix(-1, -0.1, 0, 1, 0, 0);
	-o-transform: matrix(-1, -0.1, 0, 1, 0, 0);
	-ms-transform: matrix(-1, -0.1, 0, 1, 0, 0);
	transform: matrix(-1, -0.1, 0, 1, 0, 0);
}
</style>
