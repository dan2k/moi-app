<template>
	<form-group :v="v" :label="label">
		<ckeditor
			v-bind="$attrs"
			class="form-control form-control-sm border-primary"
			:class="{
				'is-invalid': v.$error,
				'is-valid': v.$dirty && !v.$error,
			}"
			style="background-color: white; height: 100%"
			:editor="editor"
			v-model="v.$model"
			:config="editorConfig"
			@ready="onReady"
		></ckeditor>
	</form-group>
</template>

<script>
import { ref, reactive, onMounted, watch } from "vue";
import CKEditor from "@ckeditor/ckeditor5-vue";
import DocumentEditor from "@ckeditor/ckeditor5-build-decoupled-document";
import FormGroup from "@/components/form/FormGroup.vue";
export default {
	inheritAttrs: false,
	components: {
		ckeditor: CKEditor.component,
		FormGroup,
	},
	props: {
		disabled: {
			type: Boolean,
			default: false,
		},
		label: {
			type: String,
			default: "",
		},
		v: {
			type: Object,
			required: true,
		},
	},
	setup(props) {
		const editorData = ref(props.valueModel);
		const editor = ref(DocumentEditor);
		const editorConfig = reactive({
			imageRemoveEvent: {
				callback: (imagesSrc, nodeObjects) => {
					let files = [];
					imagesSrc.forEach((it, i) => {
						let tmp = it.split("/");
						files.push(tmp[tmp.length - 1]);
					});
					let data = {
						id: "3459",
						filenames: files,
					};
					fetch(
						`${
							import.meta.env.VITE_PRIVATE_API_URL
						}/delete.php`,
						{
							method: "POST",
							body: JSON.stringify(data),
							headers: {
								"Content-type":
									"application/json; charset=UTF-8",
							},
						}
					);
				},
			},
			placeholder: "เพิ่มเนื้อหา......",

			ckfinder: {
				uploadUrl: `${
					import.meta.env.VITE_PRIVATE_API_URL
				}/upload.php?id=3459`,
			},
			image: {
				toolbar: [
					"imageStyle:alignLeft",
					"imageStyle:alignCenter",
					"imageStyle:alignRight",
					"|",
					"imageStyle:full",
					"imageStyle:side",
					"|",
					"imageTextAlternative",
				],
				styles: [
					"full",
					"side",
					"alignLeft",
					"alignCenter",
					"alignRight",
				],
				resize: true,
				resizeOptions: [
					{
						name: "imageResize:original",
						label: "Original",
						value: null,
					},
					{
						name: "imageResize:50",
						label: "50%",
						value: "50",
					},
					{
						name: "imageResize:75",
						label: "75%",
						value: "75",
					},
				],
			},
			table: {
				contentToolbar: [
					"tableColumn",
					"tableRow",
					"mergeTableCells",
				],
			},
			licenseKey: "",
		});
		const onReady = (editor) => {
			// document.body.prepend(editor.ui.view.toolbar.element);
			editor.ui
				.getEditableElement()
				.parentElement.insertBefore(
					editor.ui.view.toolbar.element,
					editor.ui.getEditableElement()
				);
			editor.isReadOnly = props.disabled;
			editor.ui.view.toolbar.element.style.display = props.disabled
				? "none"
				: "";

			// editor.ui.view.editable.element.style.height = "450px";
			// editor.ui.view.editable.element.className = "col-12";
			// editor.ui.view.toolbar.element.style.wdith = "70%";
			// console.log(editor.plugins);
			//console.log(editor.ui.getEditableElement());
		};
		onMounted(() => {});

		return {
			editor,

			editorData,
			onReady,
			editorConfig,
		};
	},
};
</script>

<style scored>
p {
	color: black;
}
.form-control p {
	margin-top: 0px;
	margin-bottom: 0px;
}
</style>
