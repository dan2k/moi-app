import { ref, reactive, toRefs, watch, onMounted } from "vue";
import { api } from "@/helper/api";
import Swal from "sweetalert2";
export default function usePage(
	page,
	page_size,
	pagination_size,
	method,
	url,
	queryParams,
	emit
) {
	let state = reactive({
		rows: [],
		totals: 0,
		isLoading: false,
		totals_page: 0,
		pageArr: [],
		pageStart: 0,
		pageStop: 0,
		p_method: method,
		p_url: url,
		p_queryParams: {},
		params: queryParams,
	});
	let p_page = ref(page);
	let p_pagination_size = ref(pagination_size);
	let p_page_size = ref(page_size);
	const setPage = (p) => {
		p_page.value = p;
	};
	onMounted(async () => {
		await getData();
		state.pageStart = 1;
		state.pageStop =
			state.pageStart + p_pagination_size.value > state.totals_page
				? state.totals_page
				: state.pageStart + p_pagination_size.value - 1;
		setPageArr();
	});
	watch(p_page_size, async (v, v_old) => {
		state.totals_page = Math.ceil(state.totals / p_page_size.value);
		p_page.value =
			p_page.value > state.totals_page
				? state.totals_page
				: p_page.value;
		changePage();
	});
	watch(p_page, async (v, v_old) => {
		await changePage();
	});
	async function getData() {
		state.isLoading = true;
		state.p_queryParams = {
			page: p_page.value,
			page_size: p_page_size.value,
		};
		Object.keys(state.params).forEach((k, i) => {
			state.p_queryParams[k] = state.params[k];
		});

		try {
			const res = await api[state.p_method](
				state.p_url,
				state.p_queryParams
			);
			if (res && res.data) {
				if (res.data.status) {
					state.rows = res.data.rows;
					state.totals = res.data.totals;
					state.totals_page = Math.ceil(
						state.totals / p_page_size.value
					);
					state.isLoading = false;
					return;
				}
				state.isLoading = false;
				state.rows = [];
				state.totals = 0;
				state.totals_page = 0;
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: res.data.error,
				});
			}
		} catch (err) {
			console.log(err);
			state.isLoading = false;
		}
	}
	const changePage = async () => {
		await getData();
		let now_range = Math.ceil(p_page.value / p_pagination_size.value);
		let max_page_now_range = now_range * p_pagination_size.value;

		let stop =
			max_page_now_range >= state.totals_page
				? state.totals_page
				: max_page_now_range;
		let start =
			stop - p_pagination_size.value < 1
				? 1
				: stop == state.totals_page
				? (now_range - 1) * p_pagination_size.value + 1
				: stop - p_pagination_size.value + 1;

		state.pageStart = start;
		state.pageStop = stop;
		setPageArr();
	};

	const setPageArr = () => {
		let tmp = [];
		for (let i = state.pageStart; i <= state.pageStop; i++) {
			if (i > state.totals_page) break;
			tmp.push(i);
		}
		state.pageArr = tmp;
	};

	const next = () => {
		p_page.value++;
	};
	const prev = () => {
		p_page.value--;
	};
	const first = () => {
		p_page.value = 1;
	};
	const last = () => {
		p_page.value = state.totals_page;
	};
	const setParams = (k, v) => {
		state.params[k] = v;
	};
	return {
		setPage,
		setPageArr,
		changePage,
		getData,
		next,
		prev,
		first,
		last,
		setParams,
		p_page,
		p_pagination_size,
		p_page_size,
		...toRefs(state),
	};
}
