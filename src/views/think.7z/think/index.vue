<template>
	<div>
		<div class="col-12 mt-0 pt-0">
			<h3 class="my-0 py-0 text-primary">
				<i class="fas fa-lightbulb"></i> ระบบ THINK TANK &nbsp;<button class="btn btn-outline-primary" @click="$router.push({name:'think-post'})">+</button>
			</h3>
			<div class="line"></div>
		</div>
		<router-view></router-view>
	</div>
</template>

<script>
export default {};
</script>

<style></style>
