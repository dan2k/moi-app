<template>
	<div class="container">
		<pagination ref="page" url="/thinktank/v1/getTotals" :page_size="5">
			<template v-slot:content="props">
				<div
					class="card my-2 bg-card"
					v-for="(p, i) of props.rows"
					:key="i"
					@click="
						$router.push({
							name: 'think-comment',
							params: { id: p.think_id },
							query: {
								pid: page.p_page,
							},
							replace: true,
						})
					"
					style="cursor: pointer"
				>
					<div class="card-body py-1">
						<div class="row py-1">
							<div class="col-2 mx-0 my-0 px-0">
								<!-- <img
									:src="`${server}/imgs/member/${p.think_add_emp_id}.jpg`"
									class="border-primary rounded-circle"
									style="width: 50px; height: 50px"
								/> -->
								<div
									class="
										card
										mx-1
										pt-2
										px-0
										border-0
										text-center
										bg-secondary
									"
								>
									<p
										class="card-title text-white"
										style="font-size: 14px"
									>
										<b>{{ p.sect_id }}</b>
									</p>
									<span
										><img
											:src="`${server}/imgs/member/${p.think_add_emp_id}.jpg`"
											class="
												border-primary
												rounded-circle
											"
											style="
												width: 50px;
												height: 50px;
											"
									/></span>
									<div class="card-body my-0 py-1">
										<p
											class="
												card-title
												text-white
											"
											style="font-size: 12px"
										>
											<i
												class="
													far
													fa-comments
												"
											></i
											>&nbsp;{{
												p.think_comment
											}}&nbsp;
											<i class="far fa-eye"></i
											>&nbsp;{{
												p.think_read
											}}&nbsp;
										</p>
									</div>
								</div>
							</div>
							<div class="col-10">
								<div
									class="float-right"
									style="position: relation"
								>
									<span v-if="p.think_status == 0"
										><i
											class="
												fas
												fa-battery-empty
												text-danger
											"
											style="cursor: pointer"
											title="หัวข้อใหม่"
										></i
									></span>
									<span v-if="p.think_status == 1"
										><i
											class="
												fas
												fa-battery-half
												text-warning
											"
											style="cursor: pointer"
											title="นำเสนอราชการ"
										></i
									></span>

									<span v-if="p.think_status == 2">
										<i
											class="
												fas
												fa-battery-full
												text-success
											"
											title="ดำเนินการเรียบร้อยแล้ว"
										></i>
									</span>
								</div>
								<hr />
								<p
									style="
										font-size: 14px;
										text-indent: 2em;
										color: #f8f8fc;
									"
								>
									{{ p.think_title }}
								</p>

								<div
									class="text-default"
									style="font-size: 12px"
								>
									<b
										><span
											class="text-dark"
											style="font-size: 16px"
											><i
												class="
													far
													fa-copyright
												"
											></i></span></b
									>&nbsp;
									<span class="text-secondary">{{
										p.think_thiname
									}}</span>
								</div>
							</div>
						</div>
						<div
							class="float-right mx-0 px-0 my-0 py-0"
							style="font-size: 10px"
						>
							<div
								class="
									col-12
									px-0
									border
									border-default
									border-bottom-0
									w-100
								"
							></div>
							<!-- <i class="far fa-comments"></i>&nbsp;{{
								p.think_comment
							}}&nbsp; <i class="far fa-eye"></i>&nbsp;{{
								p.think_read
							}}&nbsp; -->
							<span class="text-white"
								><i class="far fa-clock"></i> &nbsp;{{
									p.think_date
								}}</span
							>
						</div>
					</div>
				</div>
			</template>
		</pagination>
	</div>
</template>

<script>
import { ref, onMounted } from "vue";
import { useRoute } from "vue-router";
import { useStore } from "vuex";
import Page from "./page.vue";
export default {
	components: { pagination: Page },
	setup(props, { emit }) {
		let posts = ref([]);
		let page = ref();
		const server = import.meta.env.VITE_PRIVATE_API_URL;
		const store = useStore();
		const authData = store.getters["auth/getAuthData"];
		const empid = authData.user[0].emp_id;
		const route = useRoute();
		const delPost = (id) => {};
		onMounted(() => {
			if (route.query.pid) {
				page.value.p_page = route.query.pid;
			}
		});
		return {
			posts,
			server,
			empid,
			delPost,

			page,
		};
	},
};
</script>

<style scoped>
.bg-card {
	background: rgb(193, 190, 190);
	background: linear-gradient(
		90deg,
		rgba(193, 190, 190, 1) 0%,
		rgba(82, 82, 156, 1) 95%
	);
}
</style>
