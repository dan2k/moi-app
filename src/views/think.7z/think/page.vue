<template>
	<div class="container">
		<slot></slot>
		<slot name="content" :rows="rows"> </slot>
		<loading v-if="isLoading"></loading>
		<nav aria-label="Page navigation example " v-if="totals_page > 0">
			<ul class="pagination mx-auto">
				<li class="page-item">
					<span class="page-link">แถว</span>
				</li>
				<li class="page-item">
					<select
						v-model="p_page_size"
						class="form-control page-link"
					>
						<option value="5">5</option>
						<option value="10">10</option>
						<option value="20">20</option>
						<option value="30">30</option>
					</select>
				</li>
				<li class="page-item">
					<button
						:disabled="p_page == 1"
						class="page-link"
						:class="{ 'text-secondary': p_page == 1 }"
						@click="first"
					>
						&lt;&lt;
					</button>
				</li>
				<li class="page-item">
					<button
						class="page-link"
						:class="{ 'text-secondary': p_page == 1 }"
						:disabled="p_page == 1"
						@click="prev()"
					>
						&lt;
					</button>
				</li>

				<li class="page-item" v-for="p in pageArr" :key="p">
					<button
						class="page-link"
						:class="{
							'bg-primary text-white': p_page == p,
						}"
						@click="setPage(p)"
					>
						{{ p }}
					</button>
				</li>

				<li class="page-item">
					<button
						class="page-link"
						:class="{
							'text-secondary': p_page == totals_page,
						}"
						:disabled="p_page == totals_page"
						@click="next()"
					>
						&gt;
					</button>
				</li>
				<li class="page-item">
					<button
						class="page-link"
						@click="last"
						:class="{
							'text-secondary': p_page == totals_page,
						}"
						:disabled="p_page == totals_page"
					>
						&gt;&gt;
					</button>
				</li>
				<li class="page-item">
					<span class="page-link">ไปที่-></span>
				</li>
				<li class="page-item">
					<select
						class="form-control page-link"
						v-model="p_page"
					>
						<option
							v-for="(p, i) of totals_page"
							:key="i"
							:value="p"
						>
							{{ p }}
						</option>
					</select>
				</li>
				<li>
					<span class="page-link">
						{{ `${p_page}/${totals_page}` }}</span
					>
				</li>
			</ul>
		</nav>
	</div>
</template>

<script>
import { toRefs, toRef } from "vue";
import usePage from "./page.js";

export default {
	props: {
		page: {
			type: Number,
			default: 1,
			required: false,
		},
		page_size: {
			type: Number,
			default: 5,
			required: false,
		},
		pagination_size: {
			type: Number,
			default: 5,
			required: false,
		},
		url: {
			type: String,
			default: "/thinktank/v1/getPosts",
			required: true,
		},
		method: {
			type: String,
			default: "post",
			required: false,
		},
		queryParams: {
			type: Object,
			default: {
				x: 1,
			},
			required: false,
		},
	},
	setup(props, { emit }) {
		let dbPage = usePage(
			props.page,
			props.page_size,
			props.pagination_size,
			props.method,
			props.url,
			props.queryParams,
			emit
		);
		return {
			// ...toRefs(dbPage),
			setPage: dbPage.setPage,
			setPageArr: dbPage.setPageArr,
			changePage: dbPage.changePage,
			next: dbPage.next,
			prev: dbPage.prev,
			first: dbPage.first,
			last: dbPage.last,
			setParams: dbPage.setParams,
			
			p_page: toRef(dbPage, "p_page"),
			p_pagination_size: toRef(dbPage, "p_pagination_size"),
			p_page_size: toRef(dbPage, "p_page_size"),
			rows: toRef(dbPage, "rows"),
			totals: toRef(dbPage, "totals"),
			isLoading: toRef(dbPage, "isLoading"),
			totals_page: toRef(dbPage, "totals_page"),
			pageArr: toRef(dbPage, "pageArr"),
			pageStart: toRef(dbPage, "pageStart"),
			pageStop: toRef(dbPage, "pageStop"),
			p_method: toRef(dbPage, "p_method"),
			p_url: toRef(dbPage, "p_url"),
			p_queryParams: toRef(dbPage, "p_queryParams"),
		};
	},
};
</script>

<style scoped>
nav {
	font-size: 12px;
}
nav select {
	font-size: 12px;
}
nav .page-link {
	margin-right: 3px;
}
</style>
