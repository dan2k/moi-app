<template>
	<div class="jumbotron mx-2 py-2 col-11 mx-auto">
		<div class="container mx-auto">
			<h5 class="mx-auto text-center text-primary">
				<i class="fas fa-save"></i> <u>ปรับปรุงข้อมูล</u>
			</h5>
			<form
				ref="form"
				@submit.prevent="submit"
				class="needs-validation"
				novalidate
			>
				<div class="form-row justify-content-center">
					<div class="col-12">
						<input-component
							label="หัวข้อ"
							:v="v.title"
							v-model="state.title"
						></input-component>
					</div>
				</div>
				<div class="form-row justify-content-center">
					<div class="col-12">
						<editor
							:disabled="false"
							label="รายละเอียด"
							:v="v.detail"
							v-model="state.detail"
							:url="uploadUrl"
							@delete-img="delImg"
						></editor>
					</div>
				</div>
				<div class="col-12"></div>
				<div class="col-12 text-center">
					<button class="btn btn-primary mr-2">
						<i class="fas fa-save"></i> บันทึก
					</button>
					<button
						class="btn btn-danger mr-2"
						type="button"
						@click="cancel()"
					>
						<i class="fas fa-redo-alt"></i> ยกเลิก
					</button>
					<button
						class="btn btn-warning"
						type="button"
						@click="router.back()"
					>
						<i class="fas fa-arrow-alt-circle-left"></i>
						ย้อนกลับ
					</button>
				</div>
			</form>
		</div>
	</div>
	<loading v-if="isLoading"></loading>
</template>

<script>
import { ref, reactive, computed, nextTick, onMounted } from "vue";
import useVuelidate from "@vuelidate/core";
import { required, helpers } from "@vuelidate/validators";
import Editor from "./editor.vue";
import InputComponent from "@/components/form/InputComponent.vue";
import { useRouter, useRoute } from "vue-router";
import { useStore } from "vuex";
import { api } from "@/helper/api";
import Swal from "sweetalert2";
// import Loading from "@/views/loading.vue";
export default {
	components: {
		Editor,
		InputComponent,
		// Loading,
	},
	setup() {
		const form = ref();
		const isLoading = ref(false);
		const state = reactive({ title: null, detail: null });
		const router = useRouter();
		const route = useRoute();
		const store = useStore();
		const authData = store.getters["auth/getAuthData"];
		const id = route.params.id;
		const uploadUrl = `${
			import.meta.env.VITE_PRIVATE_API_URL
		}/upload.php?id=${authData.user[0].emp_id}`;

		const rules = computed(() => ({
			title: {
				required: helpers.withMessage("ห้ามเป็นค่าว่าง", required),
			},
			detail: {
				required: helpers.withMessage("ห้ามเป็นค่าว่าง", required),
			},
		}));
		const v = useVuelidate(rules, state);
		async function submit() {
			this.v.$touch();
			if (this.v.$error) return;
			state["think_add_emp_id"] = authData.user[0].emp_id;
			state["id"] = id;
			try {
				// throw "ทดสอบครับ";

				const response = await api.post(
					"/thinktank/v1/edit",
					state
				);
				if (response && response.data) {
					if (response.data.status) {
						router.push({
							name: "think-comment",
							params: { id },
							replace: true,
						});
						return;
					}
					throw response.data.error;
				}
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
			}
			// goto list post หน้าที่สามารถเพิ่ม comment ได้
		}
		async function cancel() {
			self = this;
			//self.v["title"].$model = "";
			//self.v["detail"].$model = "";
			// await this.getPost();
			await getPost();
			nextTick(() => {
				self.v.$reset();
			});
		}
		function delImg(obj, n) {
			// if (isSubmit) {
			// 	isSubmit = false;
			// 	return;
			// }
			let files = [];
			obj.imagesSrc.forEach((it, i) => {
				let tmp = it.split("/");
				files.push(tmp[tmp.length - 1]);
			});
			let data = {
				id: authData.user[0].emp_id,
				filenames: files,
			};
			fetch(`${import.meta.env.VITE_PRIVATE_API_URL}/delete.php`, {
				method: "POST",
				body: JSON.stringify(data),
				headers: {
					"Content-type": "application/json; charset=UTF-8",
				},
			});
		}
		const getPost = async () => {
			isLoading.value = true;
			try {
				const response = await api.get(`/thinktank/v1/post/${id}`);
				if (response && response.data) {
					if (response.data.status) {
						let tmp = response.data.data;
						state.detail = tmp.think_detail;
						state.title = tmp.think_title;
						isLoading.value = false;
						return;
					}
				}
				throw response.data.error;
			} catch (err) {
				Swal.fire({
					icon: "error",
					title: '<span style="color:red">แจ้งข้อผิดพลาด</span>',
					text: err,
				});
				isLoading.value = false;
			}
		};
		onMounted(async () => {
			await getPost();
			v.value.$reset();
		});
		return {
			v,
			state,
			submit,
			cancel,
			router,
			form,
			uploadUrl,
			delImg,
			isLoading,
		};
	},
};
</script>
<style></style>
