<template>
	<form-group :v="v" :label="label">
		<div
			:class="{
				'is-invalid border border-danger rounded': v.$error,
				'is-valid border border-success rounded':
					v.$dirty && !v.$error,
			}"
		>
			<ckeditor
				v-bind="$attrs"
				class="form-control form-control-sm border-primary"
				style="background-color: white; height: 100%"
				:editor="editor"
				v-model="v.$model"
				:config="editorConfig"
				@ready="onReady"
			></ckeditor>
		</div>
	</form-group>
</template>

<script>
// const generatePtSetting = (size) => {
// 	return {
// 		model: size,
// 		title: size,
// 		view: {
// 			name: "span",
// 			styles: {
// 				"font-size": `${size}pt`,
// 			},
// 		},
// 	};
// };
import { ref, reactive, onMounted, watch } from "vue";
import CKEditor from "@ckeditor/ckeditor5-vue";
import DocumentEditor from "@ckeditor/ckeditor5-build-decoupled-document";
import FormGroup from "@/components/form/FormGroup.vue";
export default {
	inheritAttrs: false,
	components: {
		ckeditor: CKEditor.component,
		FormGroup,
	},
	props: {
		disabled: {
			type: Boolean,
			default: false,
		},
		label: {
			type: String,
			default: "",
		},
		v: {
			type: Object,
			required: true,
		},
		isCancel: {
			type: Boolean,
			default: false,
		},
		url:{
			type:String,
			required:true,
		}
	},
	setup(props, ctx) {
		const editor = ref(DocumentEditor);
		const editorConfig = reactive({
			imageRemoveEvent: {
				callback: (imagesSrc, nodeObjects) => {
					// console.log(nodeObjects);
					// console.log('ctx==>',ctx);
					if (props.isCancel) {
						ctx.emit("delete-img", {
							imagesSrc,
							nodeObjects,
						});
					} else {
						let files = [];
						imagesSrc.forEach((it, i) => {
							let tmp = it.split("/");
							files.push(tmp[tmp.length - 1]);
						});
						let data = {
							id: "3459",
							filenames: files,
						};
						fetch(
							`${
								import.meta.env.VITE_PRIVATE_API_URL
							}/delete.php`,
							{
								method: "POST",
								body: JSON.stringify(data),
								headers: {
									"Content-type":
										"application/json; charset=UTF-8",
								},
							}
						);
					}
				},
			},
			placeholder: "เพิ่มเนื้อหา......",

			ckfinder: {
				// uploadUrl: `${
				// 	import.meta.env.VITE_PRIVATE_API_URL
				// }/upload.php?id=3459`,
				uploadUrl: props.url,
			},
			// fontSize: {
			// 	options: [
			// 		generatePtSetting("10"),
			// 		generatePtSetting("12"),
			// 		generatePtSetting("14"),
			// 		"default",
			// 		generatePtSetting("18"),
			// 		generatePtSetting("20"),
			// 		generatePtSetting("22"),
			// 		generatePtSetting("24"),
			// 		generatePtSetting("26"),
			// 		generatePtSetting("28"),
			// 		generatePtSetting("30"),
			// 	],
			// },
			options: [
				{ class: "text-tiny", title: "Tiny" },
				{ class: "text-small", title: "Small" },
				{ class: "", title: "normal" }, // or maybe own setting? below
				{ class: "text-big", title: "Big" },
				{ class: "font-big", title: "Huge" },
			],
			defaultFontTitle: "Normal",

			image: {
				toolbar: [
					"imageStyle:alignLeft",
					"imageStyle:alignCenter",
					"imageStyle:alignRight",
					"|",
					"imageStyle:full",
					"imageStyle:side",
					"|",
					"imageTextAlternative",
				],
				styles: [
					"full",
					"side",
					"alignLeft",
					"alignCenter",
					"alignRight",
				],
				resize: true,
				resizeOptions: [
					{
						name: "imageResize:original",
						label: "Original",
						value: null,
					},
					{
						name: "imageResize:50",
						label: "50%",
						value: "50",
					},
					{
						name: "imageResize:75",
						label: "75%",
						value: "75",
					},
				],
			},
			table: {
				contentToolbar: [
					"tableColumn",
					"tableRow",
					"mergeTableCells",
				],
			},
			licenseKey: "",
		});

		const onReady = (editor) => {
			// document.body.prepend(editor.ui.view.toolbar.element);
			editor.ui
				.getEditableElement()
				.parentElement.insertBefore(
					editor.ui.view.toolbar.element,
					editor.ui.getEditableElement()
				);
			editor.isReadOnly = props.disabled;
			editor.ui.view.toolbar.element.style.display = props.disabled
				? "none"
				: "";

			// editor.ui.view.editable.element.style.height = "450px";
			// editor.ui.view.editable.element.className = "col-12";
			// editor.ui.view.toolbar.element.style.wdith = "70%";
			// console.log(editor.plugins);
			//console.log(editor.ui.getEditableElement());
		};
		onMounted(() => {});

		return {
			editor,
			onReady,
			editorConfig,
		};
	},
};
</script>

<style scored>
p {
	color: black;
}
.form-control p {
	margin-top: 0px;
	margin-bottom: 0px;
	line-height: 18px;
}
</style>
